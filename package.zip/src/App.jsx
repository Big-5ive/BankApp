import "./App.css";
import Route from "./routes/Route";
function App() {
  return (
    <>
     <Route />
    </>
  );
}

export default App;
