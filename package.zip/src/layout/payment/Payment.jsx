import React from 'react'

const Payment = () => {
  return (
    <div style={{color:'red'}}>Payment</div>
  )
}

export default Payment