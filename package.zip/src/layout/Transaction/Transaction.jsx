import React from 'react'

const Transaction = () => {
  return (
    <div>Transaction</div>
  )
}

export default Transaction