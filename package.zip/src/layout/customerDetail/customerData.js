const customerData = {
    name: "Audrey Jerome",
    id: "3112384778",
    email: "archillesmr@gmail.com",
    accountType: "Savings ($)",
    balance: "$900,000.00",
    profileDetails: {
      phone: "+19639991232",
      sex: "Male",
      maritalStatus: "Married",
      dateOfBirth: "30/11/2019",
      address: "West Georgia",
      activeSince: "30/11/2019",
    },
  };
  
  export default customerData;
  